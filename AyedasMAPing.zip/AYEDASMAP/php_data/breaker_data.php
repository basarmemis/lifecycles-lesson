<?php

    $constring=$_POST['constring'];



    $db = new PDO('pgsql:host=localhost;port=5432;dbname=ayedas;', 'postgres', 'a1');
    $sql = $db->prepare($constring);
    //$sql = $db->prepare("SELECT ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, gid, status FROM gis_breakers ORDER BY geom <-> ST_SetSRID(ST_MakePoint($lng, $lat), 4326) LIMIT 400;");
    $sql->execute();
    

    $features=[];
    while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        $feature=['type'=>"Feature"];
        $feature['geometry']=json_decode($row['geom']);
        unset($row['geom']);
        $feature['properties']=$row;
        array_push($features, $feature);
        }
        $featureCollection=['type'=>'FeatureCollection', 'features'=>$features];
        echo json_encode($featureCollection);
    ?>