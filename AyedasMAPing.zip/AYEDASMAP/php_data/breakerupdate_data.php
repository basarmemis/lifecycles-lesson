<?php

    $constring=$_POST['constring'];

    $db = new PDO('pgsql:host=localhost;port=5432;dbname=ayedas;', 'postgres', 'a1');
    $sql = $db->prepare($constring);
    $sql->execute();    
    

    $features=[];
    while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        $feature=['type'=>"Feature"];
        $feature['properties']=$row;
        array_push($features, $feature);
        }
        $featureCollection=['type'=>'FeatureCollection', 'features'=>$features];
        echo json_encode($featureCollection);
    ?>