<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
    $constring=$_POST['constring'];

    $db = new PDO('pgsql:host=localhost;port=5432;dbname=ayedas;', 'postgres', 'a1');
    $sql = $db->prepare($constring);
    //$sql = $db->prepare("SELECT gid, ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom FROM (SELECT *, row_number() OVER(ORDER BY geom) AS row FROM gis_lines) t WHERE t.row % 2 = 0 AND name NOT LIKE 'CONN-%';");
    //$sql = $db->prepare("SELECT gid, name, length, color, lineinfo, un, linetype, ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom FROM gis_lines ORDER BY gid ASC;");
    //$sql = $db->prepare("SELECT id, color, ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom FROM gis_lines ORDER BY id ASC;");
    //gis_lines WHERE name NOT LIKE 'CONN-%';"
    //gis_lines ORDER BY id ASC LIMIT 10000;
    $sql->execute();
    

    $features=[];
    while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        $feature=['type'=>"Feature"];
        $feature['geometry']=json_decode($row['geom']);
        unset($row['geom']);
        $feature['properties']=$row;
        array_push($features, $feature);
        }
        $featureCollection=['type'=>'FeatureCollection', 'features'=>$features];
        echo json_encode($featureCollection);
    ?>