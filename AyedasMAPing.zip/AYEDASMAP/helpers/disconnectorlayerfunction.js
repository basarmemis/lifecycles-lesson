var disconnector_layer = L.markerClusterGroup.layerSupport({
    showCoverageOnHover: false,
    singleMarkerMode: false,
    //spiderfyOnMaxZoom: true,
    removeOutsideVisibleBounds : true,
    disableClusteringAtZoom : 17,
    maxClusterRadius: 1000,
    chunkedLoading : true,
});
var disconnectors = [];
var disconnectorupdatetimeout;
var zoomcenterdisconnector;


async function disconnectordatapromise(cons){

    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log('success!');
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                rundisconnectors();
            } 
                });
      });
    };



    async function ayiricilari_getir () {
        //disconnector_layer.clearLayers();
        zoomcenterdisconnector = getzoomcenter();
        if (zoomcenterdisconnector[0] > 9) 
        {
        //console.log('18den buyuk bak bakalım');
        constring = ["SELECT ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, gid, name, status FROM gis_disconnectors ORDER BY gid", "php_data/disconnector_data.php"];
        bulk_disconnector_data = await disconnectordatapromise(constring);
        for(var i = 0; i < bulk_disconnector_data['features'].length; i++)
        {
            let coordinates = bulk_disconnector_data['features'][i]['geometry']['coordinates'];
            let gid = bulk_disconnector_data['features'][i]['properties']['gid'];
            let status = bulk_disconnector_data['features'][i]['properties']['status'];
            let name = bulk_disconnector_data['features'][i]['properties']['name'];

            icondurum = [status.toString(), '18'];
            var myIcon = disconnectoriconfunction(icondurum);

            disconnectors[i] = L.marker(coordinates,
                {
                    icon :  myIcon,
                    title : name
                });

                 disconnectors[i].on('contextmenu', function(e) {               
                    L.popup({
                    'maxWidth': '600',
                    'width': '450',
                    'className' : 'popupCustom',
                    })
                    .setLatLng(e.latlng)
                    .setContent(disconnectorpopupfunction(gid))
                    .openOn(mymap);                            
        
    });                
            disconnector_layer.addLayer(disconnectors[i]);
        
        }        
        }


    };


    async function ayiricilari_guncelle() {
        zoomcenterdisconnector = getzoomcenter();
        if (zoomcenterdisconnector[0] > 17) 
        {
            if (mymap.hasLayer(disconnector_layer)) 
            {        
                
            }
            else
            {
                mymap.addLayer(disconnector_layer);
            }
        constring = ["SELECT gid, status FROM gis_disconnectors ORDER BY gid", "php_data/disconnectorupdate_data.php"];
        update_disconnector_data = await disconnectordatapromise(constring);
        //console.log('ayirici update datasını alabildi')
        for(var i = 0; i < update_disconnector_data['features'].length; i++)
        {
            let status = update_disconnector_data['features'][i]['properties']['status'];
            icondurum = [status.toString(), zoomcenterdisconnector[0].toString()];
            var myIcon = disconnectoriconfunction(icondurum);
        
            disconnectors[i].setIcon(myIcon);
        
        }
        
        //console.log('ayiricilari güncelleme bitti');
        }
        if (zoomcenterdisconnector[0] < 18) 
        {
            //console.log('zoom 18den kucuk ayiricilari basılmıyor')
            if (mymap.hasLayer(disconnector_layer)) 
            {        
                mymap.removeLayer(disconnector_layer);
            }
        }
        disconnectorupdatetimeout = setTimeout(ayiricilari_guncelle, 6000);
    };

    async function rundisconnectors() {
        await ayiricilari_getir();
        //console.log('ayiricilari getir bitti xd');
        await ayiricilari_guncelle();
        
    };

    rundisconnectors();

    mymap.on('zoomend', async function(){
        clearTimeout(disconnectorupdatetimeout);
        await ayiricilari_guncelle();
    });