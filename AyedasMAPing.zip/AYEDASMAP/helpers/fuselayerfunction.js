var fuse_layer = L.markerClusterGroup.layerSupport({
    showCoverageOnHover: false,
    singleMarkerMode: false,
    //spiderfyOnMaxZoom: true,
    removeOutsideVisibleBounds : true,
    disableClusteringAtZoom : 17,
    maxClusterRadius: 1000,
    chunkedLoading : true,
});
var fuses = [];
var fuseupdatetimeout;
var zoomcenterfuse;


async function fusedatapromise(cons){

    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log('success!');
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                runfuses();
            } 
                });
      });
    };



    async function sigortalari_getir () {
        //fuse_layer.clearLayers();
        zoomcenterfuse = getzoomcenter();
        if (zoomcenterfuse[0] > 9) 
        {
        //console.log('18den buyuk bak bakalım');
        constring = ["SELECT ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, gid, name, status FROM gis_fuses ORDER BY gid", "php_data/fuse_data.php"];
        bulk_fuse_data = await fusedatapromise(constring);
        for(var i = 0; i < bulk_fuse_data['features'].length; i++)
        {
            let coordinates = bulk_fuse_data['features'][i]['geometry']['coordinates'];
            let gid = bulk_fuse_data['features'][i]['properties']['gid'];
            let status = bulk_fuse_data['features'][i]['properties']['status'];
            let name = bulk_fuse_data['features'][i]['properties']['name'];

            icondurum = [status.toString(), '18'];
            var myIcon = fuseiconfunction(icondurum);

            fuses[i] = L.marker(coordinates,
                {
                    icon :  myIcon,
                    title : name
                });

                 fuses[i].on('contextmenu', function(e) {               
                    L.popup({
                    'maxWidth': '600',
                    'width': '450',
                    'className' : 'popupCustom',
                    })
                    .setLatLng(e.latlng)
                    .setContent(fusepopupfunction(gid))
                    .openOn(mymap);                            
        
    });                
            fuse_layer.addLayer(fuses[i]);
        
        }        
        }


    };


    async function sigortalari_guncelle() {
        zoomcenterfuse = getzoomcenter();
        if (zoomcenterfuse[0] > 17) 
        {
            if (mymap.hasLayer(fuse_layer)) 
            {        
                
            }
            else
            {
                mymap.addLayer(fuse_layer);
            }
        constring = ["SELECT gid, status FROM gis_fuses ORDER BY gid", "php_data/fuseupdate_data.php"];
        update_fuse_data = await fusedatapromise(constring);
        //console.log('sigorta update datasını alabildi')
        for(var i = 0; i < update_fuse_data['features'].length; i++)
        {
            let status = update_fuse_data['features'][i]['properties']['status'];
            icondurum = [status.toString(), zoomcenterfuse[0].toString()];
            var myIcon = fuseiconfunction(icondurum);
        
            fuses[i].setIcon(myIcon);
        
        }
        
        //console.log('sigortalari güncelleme bitti');
        }
        if (zoomcenterfuse[0] < 18) 
        {
            //console.log('zoom 18den kucuk sigortalari basılmıyor')
            if (mymap.hasLayer(fuse_layer)) 
            {        
                mymap.removeLayer(fuse_layer);
            }
        }
        fuseupdatetimeout = setTimeout(sigortalari_guncelle, 6000);
    };

    async function runfuses() {
        await sigortalari_getir();
        //console.log('sigortalari getir bitti xd');
        await sigortalari_guncelle();
        
    };

    runfuses();

    mymap.on('zoomend', async function(){
        clearTimeout(fuseupdatetimeout);
        await sigortalari_guncelle();
    });