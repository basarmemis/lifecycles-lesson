function breakerpopupfunction(gid) {
    var content;
    constring1 = "SELECT name, quality, sp5path, status FROM gis_breakers WHERE gid =" + gid.toString();
    $.ajax({
        url:"php_oznitelik/breakeroznitelik_data.php",
        async: false,
        cache: false,
        type:'POST',
        dataType: "json",
        data:{
            constring:constring1
            },
        success: function(response)
            {
                let name = response['features'][0]['properties']['name'];
                let status = response['features'][0]['properties']['status'];
                let quality = response['features'][0]['properties']['quality'];
                let sp5path = response['features'][0]['properties']['sp5path'];
                var dta = [];
                dta = ["gid","UPDATE gis_disconnectors SET status = 2, quality = '$kalite' WHERE gid = '$objeid';"]

                var list = '<h4>Ayirici Durum</h4>' + '<table style="width:450px;" border="1"><tr><th>ID</th><th>Name</th><th>Pozisyon</th>' +
                '<th>Sinyal Kalitesi</th>' +
                '<th>SP5_Path</th>' +
                '<th>Manual Update</th>' +
                '<th>Manual Update</th>' +
                '</tr><tr><td>'
                + gid + '</td><td>' + name + '</td><td>' + status + '</td>' +
                '<td>' + quality + '</td>' +
                '<td>' + sp5path + '</td>' + 
                '<td><button onclick="bmyfuncac(' + gid + ')" class="form-control btn-primary">Aç</button></td>' + '<td><button onclick="bmyfunckapat(' + gid
                + ')" class="form-control btn-primary">Kapat</button></td>' +'</tr>' + '</table>';
                content = list;                 
            },
        error: function(err)
        {
            //console.log(err);
        } 
            });
        return content;

};