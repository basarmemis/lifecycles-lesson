function linepopupfunction(gid) {
    var content;
    constring1 = "SELECT name, length, lineinfo, un, loading, power, pafta_id, source FROM gis_lines WHERE gid =" + gid.toString();
    $.ajax({
        url:"php_oznitelik/lineoznitelik_data.php",
        async: false,
        cache: false,
        type:'POST',
        dataType: "json",
        data:{
            constring:constring1
            },
        success: function(response)
            {
                let name = response['features'][0]['properties']['name'];
                let length = response['features'][0]['properties']['length'];
                let lineinfo = response['features'][0]['properties']['lineinfo'];
                let un = response['features'][0]['properties']['un'];
                let linetype = response['features'][0]['properties']['linetype'];
                let power = response['features'][0]['properties']['power'];
                let loading = response['features'][0]['properties']['loading'];
                let pafta_id = response['features'][0]['properties']['pafta_id'];
                let source = response['features'][0]['properties']['source'];
                //pafta_id = 1500;

                var list = '<h4>Line Öznitelikleri</h4>' 
                + '<table style="width:450px;" border="1"><tr><th>ID</th><th>Name</th><th>Length</th><th>LineInfo</th><th>Un</th>' +
                '<th>LineType</th>' +
                '<th>Power</th>' +
                '<th>Loading</th>' +
                '<th>Pafta Getir</th>' + 
                '<th>Pafta Getir</th>' + 
                '</tr><tr><td>'
                + gid.toString() + '</td><td>' + name + '</td><td>' + length.toString() + '</td><td>' + lineinfo + '</td><td>' + un + '</td>' +
                '<td>' + linetype + '</td>' +
                '<td>' + power + '</td>' +
                '<td>' + loading + '</td>' +
                '<td><button onclick="benimfonksiyon01(' + pafta_id + ',' + source + ')" class="form-control btn-primary">DownStream</button></td>' +
                '<td><button onclick="benimfonksiyon01(' + pafta_id + ',' + source + ')" class="form-control btn-primary">UpStream</button></td>' +
                '</tr>' + '</table>';
                content = list;
            },
        error: function(err)
        {
            //console.log(err);
        } 
            });
        return content;

};

async function benimfonksiyon01(paftaid, source_) {
    console.log("pafta cagrıldı" + paftaid.toString());
    //var win = window.open("http://192.168.137.42/paftason/paftason.html", "noopener");
    //var win = window.open("http://192.168.137.42/pafta_GIS/pafta.html?paftaid=" + dta.toString(), "_blank", "noopener");

    if(paftaid.toString() == '0') 
    {
        var win = window.open("http://localhost/PAFTAgis/index.html?paftaid=" + source_.toString(), "_blank", "noopener");
    }
    else
    {
        var win = window.open("http://localhost/PAFTAgis/index.html?paftaid=" + paftaid.toString() + "&endid=" + source_.toString(), "_blank", "noopener");
    }
    win.focus();
};