function disconnectoriconfunction(e) {
    var url;
    var size;
    if (e[0] == 1){
        url = 'img/ayiriciacik.png';
    }
    else if (e[0] == 2){
        url = 'img/ayiricikapali.png';
    }
    else
    {
        url = 'img/ayiricikapali.png';
    }

    if (e[1] == 18) {
        size = [6,6];
    }
    else if (e[1] == 19) {
        size = [7,7];
    }
    else if (e[1] == 20) {
        size = [8,8];
    }
    else if (e[1] == 21) {
        size = [9,9];
    }
    else if (e[1] == 22) {
        size = [10,10];
    }
    else if (e[1] == 23) {
        size = [17,17];
    }
    else if (e[1] == 24) {
        size = [25,25];
    }
    else if (e[1] == 25) {
        size = [30,30];
    }
    else {
        size = [1,1];
    }

    ico = L.icon({iconUrl: url, iconSize:size});
    return ico;     
            
};