function transformerpopupfunction(gid) {
    var content;
    constring1 = "SELECT name, un1, un2, sn FROM gis_transformers WHERE gid =" + gid.toString();
    $.ajax({
        url:"php_oznitelik/transformeroznitelik_data.php",
        async: false,
        cache: false,
        type:'POST',
        dataType: "json",
        data:{
            constring:constring1
            },
        success: function(response)
            {
                let name = response['features'][0]['properties']['name'];
                let un1 = response['features'][0]['properties']['un1'];
                let un2 = response['features'][0]['properties']['un2'];
                let sn = response['features'][0]['properties']['sn'];

                var list = '<h4>Trafo Öznitelikleri</h4>' + '<table style="width:450px;" border="1"><tr><th>ID</th><th>Name</th><th>Un1</th><th>Un2</th><th>Sn</th></tr><tr><td>'
                + gid + '</td><td>' + name + '</td><td>' + un1 + '</td><td>' + un2 + '</td><td>' 
                + sn + '</td></tr>' + '</table>';
                content = list;               
            },
        error: function(err)
        {
            //console.log(err);
        } 
            });
        return content;

};