function uzaklik(a) {
   l1 = (a[1].lat - a[0].lat) * (a[1].lat - a[0].lat) + (a[1].lng - a[0].lng) * (a[1].lng - a[0].lng);
   if (l1 == 0) {l2 = 0;}
   else {l2 = Math.sqrt(l1);}
   return l2; 
};