function fusepopupfunction(gid) {
    var content;
    constring1 = "SELECT name, quality, status FROM gis_fuses WHERE gid =" + gid.toString();
    $.ajax({
        url:"php_oznitelik/fuseoznitelik_data.php",
        async: false,
        cache: false,
        type:'POST',
        dataType: "json",
        data:{
            constring:constring1
            },
        success: function(response)
            {
                let name = response['features'][0]['properties']['name'];
                let status = response['features'][0]['properties']['status'];
                let quality = response['features'][0]['properties']['quality'];

                var list = '<h4>Sigorta Durum</h4>' + '<table style="width:450px;" border="1"><tr><th>ID</th><th>Name</th><th>Pozisyon</th><th>Sinyal Kalitesi</th><th>Manual Update</th><th>Manual Update</th></tr><tr><td>'
                + gid + '</td><td>' + name + '</td><td>' + status + '</td><td>' + quality + '</td>' 
                + '<td><button onclick="dmyfuncac(' + gid + ')" class="form-control btn-primary">Aç</button></td>' + '<td><button onclick="dmyfunckapat(' + gid
                + ')" class="form-control btn-primary">Kapat</button></td>' +'</tr>' + '</table>';
                content = list;               
            },
        error: function(err)
        {
            //console.log(err);
        } 
            });
        return content;

};