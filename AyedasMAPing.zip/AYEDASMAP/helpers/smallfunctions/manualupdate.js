function bmyfunckapat(e) {
    $.ajax({
    url:'manuelupdate/bmanuelupdate_closed.php',
    async: true,
    cache: false,
    type:'POST',
    data:{
          id: e,
          quality: ('Entered Valid')
         },
    success: function(response)
    {
    alert(response.toString());
    }
    });
    //console.log((e).toString());
    };




    function bmyfuncac(e) {
    $.ajax({
    url:'manuelupdate/bmanuelupdate_open.php',
    async: true,
    cache: false,
    type:'POST',
    data:{
          id: e,
          quality: ('Entered Valid')
         },
    success: function(response)
    {
    alert(response.toString());
    }
    });
    //console.log((e).toString());
    };
    function markerOnClick(){                
    alert("hi. you clicked the marker at " + this.feature.properties.name);
    //alert("hi. you clicked the marker at " + e);
    };
    
    
    function dmyfunckapat(e) {
      $.ajax({
      url:'manuelupdate/dmanuelupdate_closed.php',
      async: true,
      cache: false,
      type:'POST',
      data:{
            id: e,
            quality: ('Entered Valid')
           },
      success: function(response)
      {
      alert(response.toString());
      }
      });
      //console.log((e).toString());
      };
  
  
  
  
      function dmyfuncac(e) {
      $.ajax({
      url:'manuelupdate/dmanuelupdate_open.php',
      async: true,
      cache: false,
      type:'POST',
      data:{
            id: e,
            quality: ('Entered Valid')
           },
      success: function(response)
      {
      alert(response.toString());
      }
      });
      //console.log((e).toString());
      };
      function markerOnClick(){                
      alert("hi. you clicked the marker at " + this.feature.properties.name);
      //alert("hi. you clicked the marker at " + e);
      }; 