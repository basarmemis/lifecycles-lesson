var transformer_layer = L.markerClusterGroup.layerSupport({
    showCoverageOnHover: false,
    singleMarkerMode: false,
    //spiderfyOnMaxZoom: true,
    removeOutsideVisibleBounds : true,
    disableClusteringAtZoom : 17,
    maxClusterRadius: 1000,
    chunkedLoading : true,
});
var transformers = [];
var transformerupdatetimeout;
var zoomcentertransformer;


async function transformerdatapromise(cons){

    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log(Math.sqrt(9));
                    //console.log('noldu');
                    //console.log('success!');
                    
                    
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                runtransformers();
            } 
                });
      });
    };



    async function trafolari_getir () {
        //transformer_layer.clearLayers();
        zoomcentertransformer = getzoomcenter();
        if (zoomcentertransformer[0] > 9) 
        {
        //console.log('18den buyuk bak bakalım');
        constring = ["SELECT ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, gid, name FROM gis_transformers ORDER BY gid", "php_data/transformer_data.php"];
        bulk_transformer_data = await transformerdatapromise(constring);
        for(var i = 0; i < bulk_transformer_data['features'].length; i++)
        {
            let coordinates = bulk_transformer_data['features'][i]['geometry']['coordinates'];
            let gid = bulk_transformer_data['features'][i]['properties']['gid'];
            let name = bulk_transformer_data['features'][i]['properties']['name'];

            icondurum = ['1', '18'];
            var myIcon = transformericonfunction(icondurum);

            transformers[i] = L.marker(coordinates,
                {
                    icon :  myIcon,
                    title : name
                });

                 transformers[i].on('contextmenu', function(e) {               
                    L.popup({
                    'maxWidth': '600',
                    'width': '450',
                    'className' : 'popupCustom',
                    })
                    .setLatLng(e.latlng)
                    .setContent(transformerpopupfunction(gid))
                    .openOn(mymap);                            
        
    });                
            transformer_layer.addLayer(transformers[i]);
        
        }        
        }


    };


    async function trafolari_guncelle() {
        zoomcentertransformer = getzoomcenter();
        if (zoomcentertransformer[0] > 17) 
        {
            if (mymap.hasLayer(transformer_layer)) 
            {        
                
            }
            else
            {
                mymap.addLayer(transformer_layer);
            }
        constring = ["SELECT gid FROM gis_transformers ORDER BY gid", "php_data/transformerupdate_data.php"];
        update_transformer_data = await transformerdatapromise(constring);
        //console.log('transformerupdate datasını alabildi')
        for(var i = 0; i < update_transformer_data['features'].length; i++)
        {
            
            icondurum = ['1', zoomcentertransformer[0].toString()];
            var myIcon = transformericonfunction(icondurum);
        
            transformers[i].setIcon(myIcon);
        
        }
        
        //console.log('trafolari güncelleme bitti');
        }
        if (zoomcentertransformer[0] < 18) 
        {
            //console.log('zoom 18den kucuk trafolari basılmıyor')
            if (mymap.hasLayer(transformer_layer)) 
            {        
                mymap.removeLayer(transformer_layer);
            }
        }
        transformerupdatetimeout = setTimeout(trafolari_guncelle, 10000);
    };

    async function runtransformers() {
        await trafolari_getir();
        //console.log('trafolari getir bitti xd');
        await trafolari_guncelle();
        
    };

    runtransformers();

    mymap.on('zoomend', async function(){
        clearTimeout(transformerupdatetimeout);
        await trafolari_guncelle();

    });