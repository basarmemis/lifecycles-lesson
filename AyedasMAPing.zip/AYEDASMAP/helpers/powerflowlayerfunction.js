var powerflow_layer = new L.LayerGroup();
var powerflow = [];
powerflow_layer.addTo(mymap);
var powerflowupdatetimeout;
var lastpowerflowcenter = null;
var newpowerflowcenter = null;
var distance = 0;
var lat1;
var lng1;
var flownew = [];
var flowold = [];


    async function powerflowdatapromise(cons){
    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log('success!');
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                runpowerflow();
            } 
                });
      });
    };







    async function powerflowu_getir () {
        mymap.removeLayer(powerflow_layer);
        powerflow_layer.clearLayers();
        powerflow_layer.addTo(mymap);
        //console.log('1');
        lastpowerflowcenter = (getzoomcenter())[1];
        lat1 = lastpowerflowcenter.lat;
        lng1 = lastpowerflowcenter.lng;
        constring = ["SELECT ST_AsGeoJSON(ST_FlipCoordinates(ST_GeometryN(geom, 1))) as geom, flow FROM gis_lines WHERE name NOT LIKE 'CONN-%' and name NOT LIKE 'LINK-%' ORDER BY geom <-> ST_SetSRID(ST_MakePoint(" + lng1 + "," + lat1 + "), 4326) LIMIT 1500;", "php_data/powerflow_data.php"];
        bulk_powerflow_data = await powerflowdatapromise(constring);
        //console.log('11. fonks daym (powerflow)');
        for(var i = 0; i < bulk_powerflow_data['features'].length; i++)
        {
            let coordinates = bulk_powerflow_data['features'][i]['geometry']['coordinates'];
            flowold[i] = bulk_powerflow_data['features'][i]['properties']['flow'];
            if (flowold[i] == 1) {}
            else if (flowold[i] == -1) {coordinates = coordinates.reverse();}
            else {coordinates = null;}

            powerflow[i] = L.polylineDecorator(
            coordinates,
            {
                patterns:
                [
                    {
                        offset: 1, 
                        repeat: 75, 
                        symbol: L.Symbol.arrowHead(
                            {
                                pixelSize: 10, 
                                pathOptions: {color: '#08A448', fillOpacity: 1, weight: 0}
                            })
                    }
                ]

            }
            );

            powerflow_layer.addLayer(powerflow[i]);
        }
        
        //console.log(lastpowerflowcenter);
        //console.log('powerflow ekrana basıldı');
        //console.log('2');
    };









    async function powerflowu_guncelle() {
        //console.log('2. fonks daym');
        constring = ["SELECT flow FROM gis_lines WHERE name NOT LIKE 'CONN-%' and name NOT LIKE 'LINK-%' ORDER BY geom <-> ST_SetSRID(ST_MakePoint(" + lng1 + "," + lat1 + "), 4326) LIMIT 1500;", "php_data/powerflowupdate_data.php"];
        update_powerflow_data = await powerflowdatapromise(constring);
        for(var i = 0; i < update_powerflow_data['features'].length; i++)
        {
            flownew[i] = update_powerflow_data['features'][i]['properties']['flow'];
            let coordinates = bulk_powerflow_data['features'][i]['geometry']['coordinates'];
            if (flownew[i] != flowold[i])
            {
                if (flowold[i] == -1 && flownew[i] == 1)
                {
                    coordinates = coordinates.reverse();
                }
                else if (flowold[i] == -1 && flownew[i] == 0)
                {
                    coordinates = null;
                }
                else if (flowold[i] == 1 && flownew[i] == -1)
                {
                    coordinates = coordinates.reverse();
                }
                else if (flowold[i] == 1 && flownew[i] == 0)
                {
                    coordinates = null;
                }
                else if (flowold[i] == 0 && flownew[i] == 1)
                {
                    coordinates = coordinates;
                }
                else if (flowold[i] == 0 && flownew[i] == -1)
                {
                    coordinates = coordinates.reverse();
                }
                else
                {
                    coordinates = coordinates;
                }
            powerflow[i].setPaths(coordinates);
            flowold[i] = flownew[i];
            }
            else {}   
        }
        powerflowupdatetimeout = setTimeout(powerflowu_guncelle, 10000);
        //console.log('powerflowu güncelleme bitti');
        
    };

    async function runpowerflow() {
        await powerflowu_getir();
        //console.log('powerflowu getir bitti xd');
        await powerflowu_guncelle();
        //console.log('asagıdaym');
        
    };



    mymap.on('zoomend', async function(){
        //clearTimeout(powerflowupdatetimeout);
        newpowerflowcenter = (getzoomcenter())[1];
        if(mymap.hasLayer(powerflow_layer)){

        }
        else{
            mymap.addLayer(powerflow_layer);
        }

        if (mymap.getZoom() > 19) {
            if (lastpowerflowcenter == null) {
                await runpowerflow();
            }
            else{
                veri = [newpowerflowcenter,lastpowerflowcenter];
                distance = uzaklik(veri);
                if (distance > 4*0.00265596799) {
                    await runpowerflow();
                }
            }        
        }

        if (mymap.getZoom() < 20) {
            mymap.removeLayer(powerflow_layer);
        }
    });

    mymap.on('dragend', async function() {
        if (mymap.getZoom() > 19) {
            newpowerflowcenter = (getzoomcenter())[1];
            veri = [newpowerflowcenter,lastpowerflowcenter];
            distance = uzaklik(veri);
            if (distance > 4*0.00265596799) {
                clearTimeout(powerflowupdatetimeout);
                await runpowerflow();
                //console.log('PowerFlow TEKRAR TEKRAR BASILDI');
            }
            else {

            }
        }
        else {

        }

    });

    


