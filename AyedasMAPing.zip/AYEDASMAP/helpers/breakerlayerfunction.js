var breaker_layer = L.markerClusterGroup.layerSupport({
    showCoverageOnHover: false,
    singleMarkerMode: false,
    //spiderfyOnMaxZoom: true,
    removeOutsideVisibleBounds : true,
    disableClusteringAtZoom : 17,
    maxClusterRadius: 1000,
    chunkedLoading : true,
});
var breakers = [];
var breakerupdatetimeout;
var zoomcenterbreaker;


async function breakerdatapromise(cons){

    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log(Math.sqrt(9));
                    //console.log('noldu');
                    //console.log('success!');
                    
                    
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                runbreakers();
            } 
                });
      });
    };



    async function kesicileri_getir () {
        //breaker_layer.clearLayers();
        zoomcenterbreaker = getzoomcenter();
        if (zoomcenterbreaker[0] > 9) 
        {
        //console.log('18den buyuk bak bakalım');
        constring = ["SELECT ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, gid, name, status FROM gis_breakers ORDER BY gid", "php_data/breaker_data.php"];
        bulk_breaker_data = await breakerdatapromise(constring);
        for(var i = 0; i < bulk_breaker_data['features'].length; i++)
        {
            let coordinates = bulk_breaker_data['features'][i]['geometry']['coordinates'];
            let gid = bulk_breaker_data['features'][i]['properties']['gid'];
            let status = bulk_breaker_data['features'][i]['properties']['status'];
            let name = bulk_breaker_data['features'][i]['properties']['name'];

            icondurum = [status.toString(), '18'];
            var myIcon = breakericonfunction(icondurum);

            breakers[i] = L.marker(coordinates,
                {
                    icon :  myIcon,
                    title : name
                });

                 breakers[i].on('contextmenu', function(e) {               
                    L.popup({
                    'maxWidth': '600',
                    'width': '450',
                    'className' : 'popupCustom',
                    })
                    .setLatLng(e.latlng)
                    .setContent(breakerpopupfunction(gid))
                    .openOn(mymap);                            
        
    });                
            breaker_layer.addLayer(breakers[i]);
        
        }        
        }


    };


    async function kesicileri_guncelle() {
        zoomcenterbreaker = getzoomcenter();
        if (zoomcenterbreaker[0] > 17) 
        {
            if (mymap.hasLayer(breaker_layer)) 
            {        
                
            }
            else
            {
                mymap.addLayer(breaker_layer);
            }
        constring = ["SELECT gid, status FROM gis_breakers ORDER BY gid", "php_data/breakerupdate_data.php"];
        update_breaker_data = await breakerdatapromise(constring);
        //console.log('kesici update datasını alabildi')
        for(var i = 0; i < update_breaker_data['features'].length; i++)
        {
            let status = update_breaker_data['features'][i]['properties']['status'];
            icondurum = [status.toString(), zoomcenterbreaker[0].toString()];
            var myIcon = breakericonfunction(icondurum);
        
            breakers[i].setIcon(myIcon);
        
        }
        
        //console.log('kesicileri güncelleme bitti');
        }
        if (zoomcenterbreaker[0] < 18) 
        {
            //console.log('zoom 18den kucuk kesicileri basılmıyor')
            if (mymap.hasLayer(breaker_layer)) 
            {        
                mymap.removeLayer(breaker_layer);
            }
        }
        breakerupdatetimeout = setTimeout(kesicileri_guncelle, 5000);
    };

    async function runbreakers() {
        await kesicileri_getir();
        //console.log('kesicileri getir bitti xd');
        await kesicileri_guncelle();
        
    };

    runbreakers();

    mymap.on('zoomend', async function(){
        clearTimeout(breakerupdatetimeout);
        await kesicileri_guncelle();

    });