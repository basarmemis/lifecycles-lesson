var line_layer = new L.LayerGroup();
var lines = [];
line_layer.addTo(mymap);
var lineupdatetimeout;
var dash = [];



    async function linedatapromise(cons){
    return new Promise(function(resolve,reject) {
        constring = cons;
        $.ajax({
            url:constring[1],
            async: true,
            cache: false,
            type:'POST',
            data:{
                constring:constring[0]
                },
            dataType: "json",
            success: function(response)
                {
                    //console.log('success!');
                    resolve(response);                    
                },
            error: function(err)
            {
                //console.log('erordayım');
                //console.log(err);
                runlines();
            } 
                });
      });
    };

    async function hatlari_getir () {
        //console.log('1');
        constring = ["SELECT gid, ST_AsGeoJSON(ST_FlipCoordinates(geom)) as geom, color, color2 FROM gis_lines ORDER BY gid", "php_data/line_data.php"];
        bulk_line_data = await linedatapromise(constring);
        //console.log('11. fonks daym');
        for(var i = 0; i < bulk_line_data['features'].length; i++)
        {
            let coordinates = bulk_line_data['features'][i]['geometry']['coordinates'];
            let color = bulk_line_data['features'][i]['properties']['color'];
            let color2 = bulk_line_data['features'][i]['properties']['color2'];
            let gid = bulk_line_data['features'][i]['properties']['gid'];
        if (color2 == null) 
        {
            lines[i] = L.polyline(coordinates);
            lines[i].on('contextmenu', function(e) {               
                                L.popup({
                                'maxWidth': '600',
                                'width': '450',
                                'className' : 'popupCustom',
                                })
                                .setLatLng(e.latlng)
                                .setContent(linepopupfunction(gid))
                                .openOn(mymap);                            
                    
                });
            line_layer.addLayer(lines[i]);
            
        }
        if (color2 != null)
        {
            lines[i] = L.polyline(coordinates, {color : color, weight:3});
            dash[i] = L.polyline(coordinates, {color: color2, weight:3, dashArray: '8, 16'});
        lines[i].on('contextmenu', function(e) {               
            L.popup({
            'maxWidth': '600',
            'width': '450',
            'className' : 'popupCustom',
            })
            .setLatLng(e.latlng)
            .setContent(linepopupfunction(gid))
            .openOn(mymap);                            

        });

        dash[i].on('contextmenu', function(e) {               
            L.popup({
            'maxWidth': '600',
            'width': '450',
            'className' : 'popupCustom',
            })
            .setLatLng(e.latlng)
            .setContent(linepopupfunction(gid))
            .openOn(mymap);                            

        });


        line_layer.addLayer(dash[i]);
        line_layer.addLayer(lines[i]);        
        }

        }
        //console.log('hatlar ekrana basıldı');
        //console.log('2');
    };

    async function hatlari_guncelle() {
        //console.log('2. fonks daym');
        constring = ["SELECT gid, color, color2 FROM gis_lines ORDER BY gid", "php_data/lineupdate_data.php"];
        update_line_data = await linedatapromise(constring);
        for(var i = 0; i < update_line_data['features'].length; i++)
        {
            let color = update_line_data['features'][i]['properties']['color'];
            let color2 = update_line_data['features'][i]['properties']['color2'];
        if (color2 == null) 
        {
            //if(line_layer.hasLayer(dash[i])) {line_layer.removeLayer(dash[i]);}
            lines[i].setStyle({color : color, weight:3});
            
        }
        if (color2 != null)
        {
            if(line_layer.hasLayer(dash[i])) {dash[i].setStyle({color: color2, weight:3, dashArray: '8, 16'});}
            else{
                coordinates = bulk_line_data['features'][i]['geometry']['coordinates'];
                dash[i] = L.polyline(coordinates, {color: color2, weight:3, dashArray: '8, 16'});
                line_layer.addLayer(dash[i]);
            }
        }
        }
        lineupdatetimeout = setTimeout(hatlari_guncelle, 10000);
        //console.log('hatlari güncelleme bitti');
        
    };


    async function runlines() {
        await hatlari_getir();
        //console.log('hatlari getir bitti xd');
        await hatlari_guncelle();
        //console.log('asagıdaym');
        
    };

    runlines ();

    


