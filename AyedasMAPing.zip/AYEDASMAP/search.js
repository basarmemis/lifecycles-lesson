var arama_layer = new L.LayerGroup();
arama_layer.addLayer(disconnector_layer);
arama_layer.addLayer(breaker_layer);
var controlSearch = new L.Control.Search({
    position:'topright',		
    layer: arama_layer,
    initial: false,
    zoom: 25,
    marker: {
        animation: true,
        icon: false
    }
});

mymap.addControl(controlSearch);





var ourCustomControl = L.Control.extend({
 
    options: 
    {
    position: 'topright', 
    }, 
    onAdd: function (map) {
    var container = L.DomUtil.create('div', 'leaflet-bar leaflet-control leaflet-control-custom');

    container.style.backgroundColor = 'white';
    container.style.width = '30px';
    container.style.height = '30px';
    container.setAttribute("type", "text");

    container.onclick = function benimfonksiyon(){
    //console.log('buttonClicked');
    }
    return container;
    },

    });
    mymap.addControl(new ourCustomControl);