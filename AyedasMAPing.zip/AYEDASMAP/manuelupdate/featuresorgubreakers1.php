<?php

        $objeid=$_POST['id'];
        $kalite=$_POST['quality'];

        $db = new PDO('pgsql:host=localhost;port=5432;dbname=ayedas;', 'postgres', 'a1');
    $sql = $db->prepare("SELECT name, gid, status, quality FROM gis_disconnectors WHERE gid = '$objeid';");
    $sql->execute();




        
    $features=[];
    while ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        $feature['properties']=$row;
        array_push($features, $feature);
        }
        echo json_encode($features);
    ?>