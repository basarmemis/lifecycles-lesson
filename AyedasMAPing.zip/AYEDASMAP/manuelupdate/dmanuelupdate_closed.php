<?php

        $objeid=$_POST['id'];
        $kalite=$_POST['quality'];

        $db = new PDO('pgsql:host=localhost;port=5432;dbname=ayedas;', 'postgres', 'a1');
    $sql = $db->prepare("UPDATE gis_disconnectors SET status = 2, quality = '$kalite' WHERE gid = '$objeid';");
    $sql->execute();



    



        
        echo ('Ayırıcı Kapali Girildi');
    ?>